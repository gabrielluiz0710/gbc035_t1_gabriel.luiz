import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Funcionario extends Pessoa implements Serializable {
    protected int carteiraTrabalho;
    protected int RG;
    protected float salario;
    protected int anoIngresso;
    protected String cargo;

    public Funcionario(String CPF, String nome, String dataNascimento, Endereco endereco, char sexo, int carteiraTrabalho, int RG, String estadoCivil, float salario, int anoIngresso, String cargo) {
        super(CPF, nome, dataNascimento, endereco, sexo,estadoCivil);
        this.carteiraTrabalho = carteiraTrabalho;
        this.RG = RG;
        this.salario = calculaSalario(salario);
        this.anoIngresso = anoIngresso;
        this.cargo = cargo;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCarteiraTrabalho() {
        return carteiraTrabalho;
    }

    public void setCarteiraTrabalho(int carteiraTrabalho) {
        this.carteiraTrabalho = carteiraTrabalho;
    }

    public int getRG() {
        return RG;
    }

    public void setRG(int RG) {
        this.RG = RG;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }
    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public float calculaSalario(float salario){
        if(this.anoIngresso - 2023 >= 15){
            return (float) (salario + 1.1 * salario);
        } else{
            return salario;
        }
    }
}