import java.io.Serializable;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Transacoes implements Serializable {
    private Conta conta;
    private float valor;
    private String tipo;
    private String data;
    private String canal;
    SimpleDateFormat formato = new SimpleDateFormat("HH:mm/dd/MM/yyyy");
    public Transacoes(Conta conta, String data){
        this.conta = conta;
        this.valor = 0;
        this.tipo = "";
        this.data = data;
        this.data = formato.format(new Date());
    }
    public Transacoes(Conta conta, float valor, String tipo, String canal){
        this.conta = conta;
        this.valor = valor;
        this.tipo = tipo;
        this.canal = canal;
        this.data = formato.format(new Date());
    }
    public Transacoes(Conta conta, float valor, String tipo){
        this.conta = conta;
        this.valor = valor;
        this.tipo = tipo;
        this.data = formato.format(new Date());
    }

    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }
}
