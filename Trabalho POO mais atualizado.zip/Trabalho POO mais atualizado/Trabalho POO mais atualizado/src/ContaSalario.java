import java.io.Serializable;

public class ContaSalario extends Conta implements Serializable{
    private float limiteSaque;
    private float limiteTransferencia;

    public ContaSalario(Transacoes[] transacoes,int senha, boolean ativa, Agencia agencia_de_criacao, float saldo, String data_abertura,
                        String data_ultima_movimentacao, int numero, float limiteSaque, float limiteTransferencia) {
        super(transacoes,senha, ativa, agencia_de_criacao, saldo, data_abertura, data_ultima_movimentacao, numero);
        this.limiteSaque = limiteSaque;
        this.limiteTransferencia = limiteTransferencia;
    }

    public float getLimiteSaque() {
        return limiteSaque;
    }

    public void setLimiteSaque(float limiteSaque) {
        this.limiteSaque = limiteSaque;
    }

    public float getLimiteTransferencia() {
        return limiteTransferencia;
    }

    public void setLimiteTransferencia(float limiteTransferencia) {
        this.limiteTransferencia = limiteTransferencia;
    }

    public float calculaCredito(){
        return 0;
    }
}