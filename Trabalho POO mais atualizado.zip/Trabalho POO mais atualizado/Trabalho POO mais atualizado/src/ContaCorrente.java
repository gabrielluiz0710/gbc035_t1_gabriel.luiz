import java.io.Serializable;

public class ContaCorrente extends Conta implements Serializable{
    private float limiteChequeEspecial;
    private float valorTaxaAdministrativa;

    public ContaCorrente(Transacoes[] transacoes,int senha, boolean ativa, Agencia agencia_de_criacao, float saldo, String data_abertura,
                         String data_ultima_movimentacao, int numero, float limiteChequeEspecial, float valorTaxaAdministrativa) {
        super(transacoes, senha, ativa, agencia_de_criacao, saldo, data_abertura, data_ultima_movimentacao,numero);
        this.limiteChequeEspecial = limiteChequeEspecial;
        this.valorTaxaAdministrativa = valorTaxaAdministrativa;
    }

    public float getLimiteChequeEspecial() {
        return limiteChequeEspecial;
    }

    public void setLimiteChequeEspecial(float limiteChequeEspecial) {
        this.limiteChequeEspecial = limiteChequeEspecial;
    }

    public float getValorTaxaAdministrativa() {
        return valorTaxaAdministrativa;
    }

    public void setValorTaxaAdministrativa(float valorTaxaAdministrativa) {
        this.valorTaxaAdministrativa = valorTaxaAdministrativa;
    }

    public float calculaCredito(){
        return (float) (0.05 * this.getSaldo()) + 50;
    }
}