import java.io.*;

public class Cliente extends Pessoa implements Serializable{
    private Agencia agencia;
    private String nivelEscolaridade;
    private Conta[] contas;
    private int numContas;
    public Cliente(){
    }
    public Cliente(String nome, String cpf) {
        super(nome, cpf);
    }
    public Cliente(String CPF, String nome, String dataNascimento, Endereco endereco, char sexo, String estadoCivil, Agencia agencia,
                   String nivelEscolaridade, Conta[] contas){
        super(CPF, nome, dataNascimento, endereco, sexo, estadoCivil);
        this.agencia = agencia;
        this.nivelEscolaridade = nivelEscolaridade;
        this.contas = contas;
    }

    public Agencia getAgencia() {
        return agencia;
    }

    public String getNivelEscolaridade() {
        return nivelEscolaridade;
    }
    public Conta[] getContas(){
        return contas;
    }

    public void setAgencia(Agencia agencia) {
        this.agencia = agencia;
    }

    public void setContas(Conta[] contas) {
        this.contas = contas;
    }

    public void setNivelEscolaridade(String nivelEscolaridade) {
        this.nivelEscolaridade = nivelEscolaridade;
    }
}
