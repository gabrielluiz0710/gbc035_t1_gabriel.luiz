import java.io.Serializable;

public abstract class Pessoa implements Validador, Serializable {
    protected String CPF;
    protected String nome;
    protected String dataNascimento;
    protected Endereco endereco;
    protected char sexo;
    protected String estadoCivil;

    public Pessoa(String CPF, String nome, String dataNascimento, Endereco endereco, char sexo, String estadoCivil) {
        if(Validador.isCPF(CPF)){
            this.CPF = CPF;
            this.nome = nome;
            this.dataNascimento = dataNascimento;
            this.endereco = endereco;
            this.sexo = sexo;
            this.estadoCivil = estadoCivil;
        }
        else{
            throw new RuntimeException("CPF inválido");
        }
    }
    public Pessoa(String nome, String cpf) {
        this.nome = nome;
        this.CPF = cpf;
    }
    public Pessoa() {

    }
    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        if (Validador.isCPF(CPF)) {
            this.CPF = CPF;
        } else {
            throw new RuntimeException("CPF inválido");
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

}
