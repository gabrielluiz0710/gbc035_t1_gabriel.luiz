import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java . io .*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numContas = 0;

        //Agência, Gerente e Endereço:
        Endereco endereco = new Endereco("São Paulo", "SP", "Centro", "Rua A, 123");
        Agencia agencia = new Agencia(1, "Agência Central", endereco);
        Gerente gerente = new Gerente("14677821062", "João Silva", 98765, 1234, "01/01/1980", endereco,
                'M', "Solteiro", 5000.0f, 2020, "01/01/2020", agencia, true, "Gerente Geral");

        Transacoes[] t1 = new Transacoes[100], t2 = new Transacoes[100], t3 = new Transacoes[100], t4 = new Transacoes[100], t5 = new Transacoes[100];
        Conta contas[] = new Conta[100];
        contas[0] = new ContaCorrente(t1,1234, true, agencia, 1000.0f, "01/01/2023", "01/01/2023", 1111, 1000.0f, 10.0f);
        contas[1] = new ContaPoupanca(t2,1234, true, agencia, 2000.0f, "01/01/2023", "01/01/2023", 2222, 0.01f);
        numContas = 2;

        System.out.println("Seja Bem-Vindo à Agência!");
        System.out.println("Selecione:");
        System.out.println("1 - Caso seja gerente\n2 - Caso seja Cliente");
        int op = scanner.nextInt();
        if(op == 1){

            int op2 = 0;
            while (op2 != 3){
                System.out.println("----- MENU GERENTE -----");
                System.out.println("1. Criar Conta");
                System.out.println("2. Verificar remuneração");
                System.out.println("3. Sair");

                System.out.print("Escolha uma opção: ");
                op2 = scanner.nextInt();
                scanner.nextLine();

                switch (op2) {
                    case 1:
                        if(numContas < 100){
                            try {
                                gerente.criarConta(scanner, agencia, contas, numContas);
                            }catch(RuntimeException e){
                                System.out.println(e.getMessage());
                            }
                        }
                        else
                            System.out.println("Numero máximo de contas atingido!");
                        break;
                    case 2:
                        System.out.println("Salário atual: " + gerente.calculaSalario(gerente.getSalario()));
                        break;
                    case 3:
                        System.out.println("Saindo do programa...");
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
                System.out.println();
            }
        }else {
            System.out.print("Digite o número da conta: ");
            int num = scanner.nextInt();
            System.out.print("Digite a senha: ");
            int sen = scanner.nextInt();

            Conta conta = null;

            for (Conta c : contas) {
                if (c.getNumero() == num && c.getSenha() == sen) {
                    conta = c;
                    break;
                }
            }

            if (conta == null) {
                System.out.println("Número de conta ou senha incorretos. Acesso negado.");
            } else {
                System.out.println("Acesso permitido à conta " + conta.getNumero());

                int opcao = 0;

                while (opcao != 7) {
                    System.out.println("----- MENU CLIENTES -----");
                    System.out.println("1. Saque");
                    System.out.println("2. Consulta de Saldo");
                    System.out.println("3. Depósito");
                    System.out.println("4. Efetuar Pagamento");
                    System.out.println("5. Cálculo de Crédito");
                    System.out.println("6. Informações do Gerente Responsável");
                    System.out.println("7. Sair");
                    System.out.print("Escolha uma opção: ");

                    opcao = scanner.nextInt();

                    switch (opcao) {
                        case 1:
                            System.out.print("Digite o valor do saque: ");
                            float valorSaque = scanner.nextFloat();
                            System.out.print("Digite a senha novamente: ");
                            int senhaSaque = scanner.nextInt();
                            if(senhaSaque == conta.getSenha()) {
                                try {
                                    conta.saque(conta, valorSaque);
                                } catch (SaldoException e) {
                                    System.out.println(e.getMessage());
                                }
                            }else{
                                System.out.println("Senha Incorreta!");
                            }
                            break;
                        case 2:
                            conta.consultaSaldo(conta);
                            break;
                        case 3:
                            System.out.print("Digite o valor do depósito: ");
                            float valorDeposito = scanner.nextFloat();
                            System.out.print("Digite a senha novamente: ");
                            int senhaDeposito = scanner.nextInt();
                            if(senhaDeposito == conta.getSenha()) {
                                try {
                                    conta.deposito(conta, valorDeposito);
                                } catch (SaldoException e) {
                                    System.out.println(e.getMessage());
                                }
                            }else{
                                System.out.println("Senha Incorreta!");
                            }
                            break;
                        case 4:
                            System.out.print("Digite o valor do pagamento: ");
                            float valorPagamento = scanner.nextFloat();
                            System.out.print("Digite a senha novamente: ");
                            int senhaPagamento = scanner.nextInt();
                                if(senhaPagamento == conta.getSenha()) {
                                try {
                                    conta.efetuarPagamento(conta,valorPagamento);
                                }catch(SaldoException e){
                                    System.out.println(e.getMessage());
                                }
                            }else{
                                    System.out.println("Senha Incorreta!");
                                }
                            break;
                        case 5:
                            System.out.println("O crédito é de: " + conta.calculaCredito());
                            break;
                        case 6:
                            gerente.printaGerente();
                            break;
                        case 7:
                            //for ( int i = 0; i < numContas ; i ++) {
                                //contas[i].salvarContas();
                            //}

                            try {
                                FileOutputStream arq = new FileOutputStream("cliente.dat");
                                ObjectOutputStream os = new ObjectOutputStream ( arq ) ;
                                for ( int i = 0; i < numContas ; i ++) {
                                    os.writeObject(contas[i]);
                                }
                                os.close();
                                arq.close ();
                            } catch (IOException e) {
                                System.out.println("Erro ao salvar as contas: " + e.getMessage());
                            }

                            System.out.println("Encerrando o programa...");
                            break;
                        default:
                           System.out.println("Opção inválida. Tente novamente.");
                    }
                }
            }

        }
    }
}