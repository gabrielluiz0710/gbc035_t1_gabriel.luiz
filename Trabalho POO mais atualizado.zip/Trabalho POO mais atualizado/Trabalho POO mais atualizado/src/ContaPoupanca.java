import java.io.Serializable;

public class ContaPoupanca extends Conta implements Serializable{
    private float rendimentoMesAtual;

    public ContaPoupanca(Transacoes[] transacoes, int senha, boolean ativa, Agencia agencia_de_criacao, float saldo, String data_abertura,
                         String data_ultima_movimentacao, int numero, float rendimentoMesAtual) {
        super(transacoes, senha, ativa, agencia_de_criacao, saldo, data_abertura, data_ultima_movimentacao, numero);
        this.rendimentoMesAtual = rendimentoMesAtual;
    }

    public float getRendimentoMesAtual() {
        return rendimentoMesAtual;
    }

    public void setRendimentoMesAtual(float rendimentoMesAtual) {
        this.rendimentoMesAtual = rendimentoMesAtual;
    }

    public float calculaCredito(){
        return (float) (0.05 * this.getSaldo()) + (10 * rendimentoMesAtual) + 100;
    }
}
