import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Gerente extends Funcionario implements Serializable, Validador{
    private String dataIngressoGerente;
    private Agencia agencia;
    private boolean curso;

    private static float comissao = 1500;

    SimpleDateFormat formato = new SimpleDateFormat("HH:mm/dd/MM/yyyy");

    public Gerente(String CPF, String nome, int carteiraTrabalho, int RG, String dataNascimento, Endereco endereco,
                   char sexo, String estadoCivil, float salario, int anoIngresso, String dataIngressoGerente,
                   Agencia agencia, boolean curso, String cargo) {
        super(CPF, nome, dataNascimento, endereco, sexo, carteiraTrabalho, RG, estadoCivil, salario, anoIngresso, cargo);
        this.dataIngressoGerente = dataIngressoGerente;
        this.agencia = agencia;
        this.curso = curso;
    }

    public String getDataIngressoGerente() {
        return dataIngressoGerente;
    }

    public void setDataIngressoGerente(String dataIngressoGerente) {
        this.dataIngressoGerente = dataIngressoGerente;
    }

    public Agencia getAgencia() {
        return agencia;
    }

    public void setAgencia(Agencia agencia) {
        this.agencia = agencia;
    }

    public boolean isCurso() {
        return curso;
    }

    public void setCurso(boolean curso) {
        this.curso = curso;
    }

    public static float getComissao() {
        return comissao;
    }

    public static void setComissao(float comissao) {
        Gerente.comissao = comissao;
    }


    public float calculaSalario(float salario){
        return super.calculaSalario(salario) + comissao;
    }

    public void printaGerente() {
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + CPF);
        System.out.println("Ano de Ingresso: " + anoIngresso);
        System.out.println("Data de Ingresso do Gerente: " + dataIngressoGerente);
        System.out.println("Agência: " + agencia);
        System.out.println("Cargo: " + cargo);
    }
    public void criarConta(Scanner scanner, Agencia agencia, Conta[] contaS, int numcontas) {
        System.out.println("----- CRIAÇÃO DE CONTA -----");
        System.out.print("Nome do cliente: ");
        String nome = scanner.nextLine();
        System.out.print("CPF do cliente: ");
        String cpf = scanner.nextLine();
        if(!Validador.isCPF(cpf)){
            throw new RuntimeException("CPF inválido!");
        }
        Cliente cliente = new Cliente(nome,cpf);
        // Pedir os dados da conta
        System.out.print("Número da conta: ");
        int numeroConta = scanner.nextInt();
        System.out.print("Senha da conta: ");
        int senhaConta = scanner.nextInt();
        System.out.print("Saldo inicial: ");
        float saldoInicial = scanner.nextFloat();
        System.out.println("----- TIPOS DE CONTA -----");
        System.out.println("1. Conta Corrente");
        System.out.println("2. Conta Poupança");
        System.out.println("3. Conta Salário");
        System.out.print("Escolha uma opção: ");
        int op = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer do scanner
        switch (op) {
            case 1:
                numcontas++;
                contaS[numcontas] = new ContaCorrente(new Transacoes[100],senhaConta, true, this.getAgencia(),saldoInicial,
                        formato.format(new Date()),formato.format(new Date()),numeroConta,2000, 50);
                break;
            case 2:
                numcontas++;
                contaS[numcontas]= new ContaPoupanca(new Transacoes[100],senhaConta, true, this.getAgencia(),saldoInicial,
                        formato.format(new Date()),formato.format(new Date()),numeroConta,0);
                break;
            case 3:
                numcontas++;
                contaS[numcontas] = new ContaSalario(new Transacoes[100],senhaConta, true, this.getAgencia(),saldoInicial,
                        formato.format(new Date()),formato.format(new Date()),numeroConta, 1000, 500);
                break;
            case 4:
                System.out.println("Saindo do programa...");
                break;
            default:
                System.out.println("Opção inválida!");
        }
        System.out.println();
        System.out.println("Conta criada com sucesso!");
    }

}