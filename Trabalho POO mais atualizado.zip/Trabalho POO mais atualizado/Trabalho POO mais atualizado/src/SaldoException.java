public class SaldoException extends IndexOutOfBoundsException {
    SaldoException(String message){
        super(message);
    }
}
