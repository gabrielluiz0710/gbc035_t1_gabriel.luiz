import java.io.*;
import java.util.ArrayList;
import java.util.List;

public abstract class Conta implements Serializable{

    protected int senha;
    protected int numero;
    protected boolean ativa;
    Agencia agenciaCriacao;
    protected float saldo;
    protected String dataAbertura;
    protected String dataUltimaMovimentacao;
    protected Cliente clientes[];
    protected Transacoes[] transacoes;
    private int cont = 0;

    public Conta(Transacoes[] transacoes,int senha, boolean ativa, Agencia agenciaCriacao, float saldo, String data_abertura, String data_ultima_movimentacao, int numero) {
        this.transacoes = transacoes;
        this.senha = senha;
        this.ativa = ativa;
        this.agenciaCriacao = agenciaCriacao;
        this.saldo = saldo;
        this.dataAbertura = data_abertura;
        this.numero = numero;
        this.dataUltimaMovimentacao = data_ultima_movimentacao;

    }

    public Cliente[] getClientes() {
        return clientes;
    }
    public void setCliente1(Cliente cliente){
        this.clientes[0] = new Cliente();
        this.clientes[0] = cliente;
    }
    public void setCliente2(Cliente cliente){
        this.clientes[1] = new Cliente();
        this.clientes[1] = cliente;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public boolean isAtiva() {
        return ativa;
    }

    public void setAtiva(boolean ativa) {
        this.ativa = ativa;
    }

    public Agencia getAgenciaCriacao() {
        return agenciaCriacao;
    }

    public void setAgencia_de_criacao(Agencia agenciaCriacao) {
        this.agenciaCriacao = agenciaCriacao;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getDataUltimaMovimentacao() {
        return dataUltimaMovimentacao;
    }

    public void setDataUltimaMovimentacao(String dataUltimaMovimentacao) {
        this.dataUltimaMovimentacao = dataUltimaMovimentacao;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public abstract float calculaCredito();

    //-------------------------------------------------------- transações

    public void saque(Conta conta, float valor){
        if(this.saldo < valor)
            throw new SaldoException("Saldo insuficiente");
        else{
            this.setSaldo(this.saldo - valor);
            System.out.println("O saque foi realizado com sucesso.\nValor sacado: " + valor +"\nNovo saldo:" + this.saldo);
        }
        transacoes[cont] = new Transacoes(conta, valor,"SAQUE");
        cont++;
    }

    public void consultaSaldo(Conta conta){
        System.out.println("O saldo da conta é de: " + this.saldo);
        transacoes[cont] = new Transacoes(conta, 0,"CONSULTA SALDO");
        cont++;
    }

    public void deposito(Conta conta, float valor){
        if(valor <= 0)
                throw new SaldoException("ERRO! Apenas valores positivo para depósito");
        else{
            this.setSaldo(this.saldo + valor);
            System.out.println("O depósito foi realizado com sucesso.\nValor depositado: " + valor +"\nNovo saldo:" + this.saldo);
        }
        transacoes[cont] = new Transacoes(conta, valor,"DEPÓSITO");
        cont++;
    }

    public void efetuarPagamento(Conta conta, float valor){
        if(this.saldo < valor)
            throw new SaldoException("Saldo insuficiente");
        else{
            this.setSaldo(this.saldo - valor);
            System.out.println("O pagamento foi realizado com sucesso.\nValor: " + valor +"\nNovo saldo:" + this.saldo);
        }
        transacoes[cont] = new Transacoes(conta, valor,"PAGAMENTO");
        cont++;
    }
/*
    public void salvarContas() {
        try {
            FileOutputStream arq = new FileOutputStream("cliente.dat");
            ObjectOutputStream os = new ObjectOutputStream ( arq ) ;
            //os.writeObject(this.numero);
            //os.writeObject(this.saldo);
            os.writeObject(this.dataAbertura);
            os.close();
            arq.close ();
        } catch (IOException e) {
            System.out.println("Erro ao salvar as contas: " + e.getMessage());
        }
    }
*/
}